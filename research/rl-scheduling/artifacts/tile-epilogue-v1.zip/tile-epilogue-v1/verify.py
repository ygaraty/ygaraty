"""Run from the repository root with its Python environment; no kernels execute."""
import gzip
import json
from pathlib import Path
import tempfile
from ygaraty.simulation.reference import load_plan
from ygaraty.simulation.tile_epilogue import verify as verify_grouping

root = Path(__file__).resolve().parent
report = json.loads((root / 'report.json').read_text())
count = 0
for audit in report['audits']:
    if audit['status'] != 'modeled':
        continue
    name, variant = audit['workload'], audit['variant']
    with gzip.open(root / f'{name}-{variant}.json.gz', 'rt') as f:
        candidate = json.load(f)['plan']
    with tempfile.TemporaryDirectory() as temp:
        path = Path(temp) / 'plan.json'; path.write_text(json.dumps(candidate)); load_plan(path)
    if variant != 'prune':
        with gzip.open(root / f'{name}-prune.json.gz', 'rt') as f:
            baseline = json.load(f)['plan']
        verify_grouping(baseline, candidate, audit['grouping'])
    count += 1
with gzip.open(root / 'rollouts.jsonl.gz', 'rt') as f:
    rows = [json.loads(line) for line in f]
keys = {(r['workload'], r['variant'], r['scenario'], r['policy'], r['seed']) for r in rows}
assert len(rows) == len(keys) == report['rollouts'] == 672
index = {(r['workload'], r['variant'], r['scenario'], r['policy'], r['seed']): r['makespan_s'] for r in rows}
for summary in report['results']:
    subset = [r for r in rows if r['workload'] == summary['workload'] and r['variant'] == summary['variant'] and (r['seed'] == 0) == (summary['regime'] == 'deterministic')]
    gains = [100 * (1 - r['makespan_s'] / index[r['workload'], 'prune', r['scenario'], r['policy'], r['seed']]) for r in subset]
    assert abs(sum(gains) / len(gains) - summary['mean_gain_percent']) < 1e-10
print(json.dumps(dict(status='passed', validated_plans=count, structural_rewrite_checks=24, unique_rollouts=len(keys), aggregate_results=len(report['results']))))
