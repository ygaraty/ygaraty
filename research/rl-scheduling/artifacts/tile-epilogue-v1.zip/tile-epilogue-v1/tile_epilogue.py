"""Hypothetical ordered reduction + bias + ReLU tiles, retaining preactivation.

Metadata only. The synthetic operation is deliberately not a runtime kernel.
"""
import copy
import math
from .reference import digest
from ygaraty.compiler.cost import task_work

OP = 'offline_tile_epilogue'
PACK = 'offline_epilogue_pack'
WRAPPER = 'offline_epilogue_wrapper'


def partition(blocks, shape):
    if not blocks or any(len(b) != 4 or not (0 <= b[0] < b[1] <= shape[0] and 0 <= b[2] < b[3] <= shape[1]) for b in blocks):
        return False
    for i, a in enumerate(blocks):
        for b in blocks[i+1:]:
            if max(a[0], b[0]) < min(a[1], b[1]) and max(a[2], b[2]) < min(a[3], b[3]):
                return False
    return sum((b[1]-b[0])*(b[3]-b[2]) for b in blocks) == math.prod(shape)


def memory_allowance(red, shapes, bias):
    # Original partial inputs, full bias backing allocation, reduced tile,
    # biased tile, activation tile, packed pair; plus 4x reduction input/output
    # tensor footprint for temporary arrays. No BLAS computation inside the group.
    elements = math.prod(red['shape'])
    source = sum(math.prod(shapes[k]) for k in {i['value'] for i in red['inputs']} | {bias})
    scratch = 4 * (sum(math.prod(shapes[i['value']]) for i in red['inputs']) + elements)
    return 8 * (source + 5 * elements + scratch)


def transform(data, roots, budget_bytes=8 << 20, wrapper_ms=0.):
    if roots is None or budget_bytes <= 0 or not math.isfinite(wrapper_ms) or wrapper_ms < 0:
        raise ValueError('invalid output contract or limits')
    result = copy.deepcopy(data); g = result['graph']
    if g.get('owned') or g.get('replicated') or g.get('cache_affinity'):
        raise ValueError('unsupported runtime semantics')
    by_id = {t['id']: t for t in g['tasks']}
    shapes = {**{k:v['shape'] for k,v in g['leaves'].items()}, **{k:t['shape'] for k,t in by_id.items()}}
    protected = set(roots) | set(g.get('reusable', [])) | set(g.get('persistent_inputs', {}))
    if not protected <= shapes.keys(): raise ValueError('missing output')
    consumers = {k:set() for k in by_id}
    for t in by_id.values():
        for i in t['inputs']:
            if i['value'] in consumers: consumers[i['value']].add(t['id'])
    edits, removed, groups, rejected = {}, set(), [], []
    for act in by_id.values():
        if act['op'] != 'relu': continue
        reason = None
        try:
            if act['attrs'] or len(act['inputs']) != 1 or act['inputs'][0]['region'] is not None: raise ValueError('activation semantics')
            bias = by_id[act['inputs'][0]['value']]
            if bias['op'] != 'add_bias' or bias['attrs'] or len(bias['inputs']) != 2 or any(i['region'] is not None for i in bias['inputs']): raise ValueError('bias semantics')
            assembly = by_id[bias['inputs'][0]['value']]; bias_id = bias['inputs'][1]['value']
            if assembly['op'] != 'assemble' or set(assembly['attrs']) != {'shape','blocks'}: raise ValueError('assembly semantics')
            shape = assembly['shape']; blocks = assembly['attrs']['blocks']
            if shape != act['shape'] or shape != bias['shape'] or assembly['attrs']['shape'] != shape: raise ValueError('shape mismatch')
            if bias_id not in g['leaves'] or shapes[bias_id] != [1,shape[1]]: raise ValueError('bias must be row-vector leaf')
            if not partition(blocks, shape) or len(blocks) != len(assembly['inputs']): raise ValueError('not an exact partition')
            if assembly['id'] in protected or consumers[assembly['id']] != {bias['id']}: raise ValueError('assembly externally required')
            reductions = []
            for inp, block in zip(assembly['inputs'], blocks):
                r0,r1,c0,c1 = block; red = by_id[inp['value']]
                if inp['region'] is not None or red['op'] != 'add_many' or red['attrs'] or not red['inputs']: raise ValueError('not a plain completed reduction')
                if red['shape'] != [r1-r0,c1-c0]: raise ValueError('reduction shape mismatch')
                if any(i['region'] is not None or shapes[i['value']] != red['shape'] for i in red['inputs']): raise ValueError('partial input shape or region')
                if red['id'] in protected or consumers[red['id']] != {assembly['id']}: raise ValueError('reduction externally required')
                if red['id'] in removed or assembly['id'] in removed or bias['id'] in edits: raise ValueError('overlapping rewrite')
                if memory_allowance(red, shapes, bias_id) > budget_bytes: raise ValueError('memory allowance')
                if 16*math.prod(red['shape']) > 8 << 20: raise ValueError('packed output limit')
                reductions.append(red)
            if len({r['id'] for r in reductions}) != len(reductions): raise ValueError('repeated reduction tile')
            identifiers = [r['id']+'/offline_epilogue' for r in reductions]
            if any(k in shapes for k in identifiers): raise ValueError('generated ID collision')
        except (KeyError, ValueError, IndexError) as e:
            reason = str(e)
        if reason is not None:
            rejected.append(dict(activation=act['id'], reason=reason)); continue
        biased_inputs, activated_inputs = [], []
        for red, block, ident in zip(reductions, blocks, identifiers):
            r0,r1,c0,c1 = block; h,w = red['shape']
            bias_slice = dict(value=bias_id, region=[0,1,c0,c1])
            packed = dict(id=ident, op=OP, inputs=copy.deepcopy(red['inputs'])+[bias_slice], shape=[2*h,w],
                attrs=dict(original_reduction=copy.deepcopy(red), activation='relu', pack_order=['preactivation','activation'],
                    extra_work=[['add_many',task_work('add_many',{},(h,w),[(h,w)]*len(red['inputs']))],
                                ['add_bias',task_work('add_bias',{},(h,w),[(h,w),(1,w)])],
                                ['relu',task_work('relu',{},(h,w),[(h,w)])], [PACK,4*h*w], [WRAPPER,wrapper_ms]]))
            edits[red['id']] = packed
            biased_inputs.append(dict(value=ident,region=[0,h,0,w]))
            activated_inputs.append(dict(value=ident,region=[h,2*h,0,w]))
        for old, inputs in ((bias,biased_inputs),(act,activated_inputs)):
            edits[old['id']] = dict(id=old['id'],op='assemble',inputs=inputs,shape=list(shape),attrs=copy.deepcopy(assembly['attrs']))
        removed.add(assembly['id'])
        groups.append(dict(assembly=assembly['id'],bias=bias['id'],activation=act['id'],bias_leaf=bias_id,
                           reductions=[r['id'] for r in reductions],packed=identifiers,blocks=blocks,
                           memory_allowances_bytes=[memory_allowance(r,shapes,bias_id) for r in reductions]))
    g['tasks'] = [edits.get(t['id'],t) for t in g['tasks'] if t['id'] not in removed]
    result['graph_sha256'] = digest(g)
    result['provenance'] = dict(kind='offline ordered tile epilogue hypothesis',source_graph_sha256=data['graph_sha256'])
    cert = dict(groups=groups,rejected=rejected,roots=sorted(roots),budget_bytes=budget_bytes,wrapper_ms=wrapper_ms)
    verify(data,result,cert)
    return result,cert


def verify(original, candidate, cert):
    """Check exact partitions, unchanged reduction operands and retained tensor IDs."""
    old = {t['id']:t for t in original['graph']['tasks']}; new = {t['id']:t for t in candidate['graph']['tasks']}
    shapes = {**{k:v['shape'] for k,v in original['graph']['leaves'].items()},**{k:t['shape'] for k,t in old.items()}}
    changed, added, removed = set(), set(), set()
    for group in cert['groups']:
        asm = old[group['assembly']]; shape = asm['shape']
        original_bias = old[group['bias']]; original_act = old[group['activation']]
        assert original_bias['op'] == 'add_bias' and not original_bias['attrs']
        assert original_bias['inputs'] == [dict(value=asm['id'],region=None), dict(value=group['bias_leaf'],region=None)]
        assert original_act['op'] == 'relu' and not original_act['attrs']
        assert original_act['inputs'] == [dict(value=original_bias['id'],region=None)]
        assert len(group['reductions']) == len(group['packed']) == len(group['blocks']) == len(group['memory_allowances_bytes'])
        assert partition(group['blocks'],shape) and group['blocks'] == asm['attrs']['blocks']
        assert group['reductions'] == [i['value'] for i in asm['inputs']]
        for red_id, packed_id, block in zip(group['reductions'],group['packed'],group['blocks']):
            red=old[red_id]; packed=new[packed_id]; h,w=red['shape']; r0,r1,c0,c1=block
            assert packed['op']==OP and packed['shape']==[2*h,w]
            assert packed['attrs']['original_reduction']==red
            assert packed['attrs']['activation']=='relu' and packed['attrs']['pack_order']==['preactivation','activation']
            assert packed['inputs']==red['inputs']+[dict(value=group['bias_leaf'],region=[0,1,c0,c1])]
            assert packed['attrs']['extra_work']==[['add_many',task_work('add_many',{},(h,w),[(h,w)]*len(red['inputs']))],['add_bias',task_work('add_bias',{},(h,w),[(h,w),(1,w)])],['relu',task_work('relu',{},(h,w),[(h,w)])],[PACK,4*h*w],[WRAPPER,cert['wrapper_ms']]]
            assert memory_allowance(red,shapes,group['bias_leaf'])<=cert['budget_bytes']
            removed.add(red_id);added.add(packed_id)
        for name,offset in ((group['bias'],0),(group['activation'],1)):
            task=new[name]
            inputs=[]
            for red_id,packed_id in zip(group['reductions'],group['packed']):
                h,w=old[red_id]['shape'];inputs.append(dict(value=packed_id,region=[offset*h,(offset+1)*h,0,w]))
            assert task==dict(id=name,op='assemble',inputs=inputs,shape=shape,attrs=asm['attrs'])
            changed.add(name)
        assert group['memory_allowances_bytes'] == [memory_allowance(old[k],shapes,group['bias_leaf']) for k in group['reductions']]
        removed.add(asm['id'])
    assert {k:v for k,v in candidate['graph'].items() if k != 'tasks'} == {k:v for k,v in original['graph'].items() if k != 'tasks'}
    assert set(new)==(set(old)-removed)|added
    assert all(new[k]==v for k,v in old.items() if k not in removed|changed)
    assert candidate['graph']['leaves']==original['graph']['leaves']
    assert set(cert['roots'])<=set(new)|candidate['graph']['leaves'].keys()
    assert candidate['graph_sha256']==digest(candidate['graph'])
    return True
