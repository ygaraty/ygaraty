"""Offline structural checks only; no numerical kernel execution."""
import copy
import unittest
from ygaraty.simulation.reference import digest
from ygaraty.simulation.tile_epilogue import transform, verify, OP


class TileEpilogueTests(unittest.TestCase):
    def fixture(self):
        def task(k,op,inputs,shape,attrs=None):
            return dict(id=k,op=op,inputs=[dict(value=v,region=None) for v in inputs],shape=shape,attrs=attrs or {})
        tasks=[task('r0','add_many',['p0','p1','p0'],[2,2]),task('r1','add_many',['p2','p3'],[2,2]),
               task('product','assemble',['r0','r1'],[2,4],dict(shape=[2,4],blocks=[[0,2,0,2],[0,2,2,4]])),
               task('pre','add_bias',['product','bias'],[2,4]),task('act','relu',['pre'],[2,4]),
               task('back','relu_backward',['pre','gradient'],[2,4])]
        g=dict(tasks=tasks,leaves={**{k:dict(shape=[2,2]) for k in ('p0','p1','p2','p3')},'bias':dict(shape=[1,4]),'gradient':dict(shape=[2,4])},
               reusable=[],owned=False,owner_keys=[])
        return dict(schema_version=1,graph=g,graph_sha256=digest(g))

    def test_tiles_preserve_repeated_reduction_order_and_backward(self):
        data=self.fixture(); before=copy.deepcopy(data)
        result,cert=transform(data,['act','pre','back'])
        self.assertEqual(len(cert['groups']),1)
        self.assertTrue(verify(data,result,cert));self.assertEqual(data,before)
        tasks={t['id']:t for t in result['graph']['tasks']}
        self.assertEqual(tasks['back'],data['graph']['tasks'][-1])
        self.assertEqual([i['value'] for i in tasks['r0/offline_epilogue']['inputs'][:-1]],['p0','p1','p0'])
        self.assertEqual(tasks['pre']['inputs'][1]['region'],[0,2,0,2])
        self.assertEqual(tasks['act']['inputs'][1]['region'],[2,4,0,2])
        self.assertEqual(tasks['r1/offline_epilogue']['inputs'][-1]['region'],[0,1,2,4])
        tasks['r0/offline_epilogue']['inputs'].reverse()
        with self.assertRaises(AssertionError):verify(data,result,cert)

    def test_reject_memory_outputs_fanout_wire_partition_and_bias(self):
        for kind in ('memory','required_product','required_reduction','fanout','wire','overlap','bias_shape'):
            d=self.fixture();roots=['act','back'];budget=8<<20
            if kind=='memory':budget=1
            elif kind=='required_product':roots.append('product')
            elif kind=='required_reduction':roots.append('r0')
            elif kind=='fanout':d['graph']['tasks'][-1]['inputs'][0]['value']='r0'
            elif kind=='wire':d['graph']['tasks'][0]['attrs']['wire']='bf16'
            elif kind=='overlap':d['graph']['tasks'][2]['attrs']['blocks'][1]=[0,2,1,3]
            else:d['graph']['leaves']['bias']['shape']=[2,4]
            result,cert=transform(d,roots,budget)
            self.assertFalse(cert['groups'],kind)
            self.assertTrue(cert['rejected'],kind)
            self.assertEqual(result['graph'],d['graph'])

    def test_missing_roots_and_owned_rejected(self):
        d=self.fixture()
        with self.assertRaises(ValueError):transform(d,None)
        with self.assertRaises(ValueError):transform(d,['absent'])
        d['graph']['owned']=True
        with self.assertRaises(ValueError):transform(d,['act'])
