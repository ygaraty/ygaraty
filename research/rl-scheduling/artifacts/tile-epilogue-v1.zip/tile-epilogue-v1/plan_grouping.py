"""Offline, output-aware grouping hypotheses. Never execute workload kernels."""
import argparse
import copy
import gzip
import json
import math
from pathlib import Path
import statistics
import tempfile
from unittest.mock import patch
import zipfile

from ygaraty.compiler.cost import task_work
from ygaraty.compiler.plan import Task, Input, group
from .cost import CostModel
from .plan_simplify import simplify, output_contract
from .reference import digest, load_plan
from .rl_dataset import collect
from .rl_counterfactual import settings_for

# Small, read-only kernels with bounded elementwise scratch. Deliberately exclude
# matmul, reductions, metadata, wire conversions, nested groups and owned ops.
ATTRS = {'add': set(), 'mul': set(), 'scale': {'factor'}, 'relu': set(),
         'relu_backward': set(), 'sigmoid': set(), 'sigmoid_backward': set(),
         'tanh': set(), 'tanh_backward': set(), 'add_bias': set()}
MODEL_OP = 'offline_group'


def bounded_group(data, roots, max_ops=4, budget_bytes=8 << 20,
                  mode="cheap", blas_scratch_bytes=1 << 20):
    if mode not in ('cheap', 'matmul_activation') or blas_scratch_bytes < 0:
        raise ValueError('invalid grouping mode or BLAS scratch reserve')
    if roots is None:
        raise ValueError('required output contract missing')
    if max_ops < 2 or budget_bytes < 1:
        raise ValueError('invalid grouping limits')
    result = copy.deepcopy(data)
    g = result['graph']
    if g.get('owned') or g.get('replicated') or g.get('cache_affinity'):
        raise ValueError('unsupported runtime semantics')
    tasks = [Task(t['id'], t['op'], [Input(**i) for i in t['inputs']], tuple(t['shape']), t['attrs']) for t in g['tasks']]
    by_id = {t.id: t for t in tasks}
    shapes = {**{k: v['shape'] for k, v in g['leaves'].items()}, **{t.id: t.shape for t in tasks}}
    if not set(roots) <= shapes.keys():
        raise ValueError('missing required output')
    protected = set(roots) | set(g.get('reusable', [])) | set(g.get('persistent_inputs', {}))
    consumers = {t.id: set() for t in tasks}
    for t in tasks:
        for dep in t.dependencies & by_id.keys():
            consumers[dep].add(t.id)
    activations = {'relu', 'sigmoid', 'tanh'}
    allowed = ATTRS if mode == 'cheap' else {'matmul': set(), 'add_bias': set(), **{k: set() for k in activations}}
    def eligible(t):
        return t.op in allowed and set(t.attrs) <= allowed[t.op]
    def nbytes(k):
        return 8 * math.prod(shapes[k])
    def memory(chain):
        ids = {t.id for t in chain}
        external = set().union(*(t.dependencies for t in chain)) - ids
        # Full sources (not just sliced views), all internal results retained,
        # plus four times the largest node's input/output tensor footprint.
        # This is an admission allowance, not a native allocator/RSS proof.
        scratch = 4 * max(sum(nbytes(i.value) for i in t.inputs) + nbytes(t.id) for t in chain)
        reserve = blas_scratch_bytes if any(t.op == 'matmul' for t in chain) else 0
        return sum(map(nbytes, external)) + sum(nbytes(t.id) for t in chain) + scratch + reserve
    used, out, certificates = set(), [], []
    rejected = {'memory': 0, 'protected': 0, 'fanout_or_terminal': 0, 'join': 0, 'unsupported': 0, 'incomplete_activation': 0}
    paths = []
    for first in tasks:
        if first.id in used:
            continue
        chain = [first]
        if eligible(first) and (mode == 'cheap' or first.op == 'matmul'):
            while len(chain) < max_ops:
                tail = chain[-1]
                if mode == 'matmul_activation' and tail.op in activations:
                    break
                if tail.id in protected:
                    rejected['protected'] += 1; break
                if len(consumers[tail.id]) != 1:
                    rejected['fanout_or_terminal'] += 1; break
                nxt = by_id[next(iter(consumers[tail.id]))]
                valid_next = mode == 'cheap' or nxt.op in activations or (len(chain) == 1 and nxt.op == 'add_bias')
                if nxt.id in used or not eligible(nxt) or not valid_next:
                    rejected['unsupported'] += 1; break
                if nxt.dependencies & by_id.keys() != {tail.id}:
                    rejected['join'] += 1; break
                if memory(chain + [nxt]) > budget_bytes:
                    rejected['memory'] += 1; break
                chain.append(nxt)
        else:
            rejected['unsupported'] += 1
        if mode == 'matmul_activation' and first.op == 'matmul':
            paths.append(dict(start=first.id, immediate_consumers=[dict(id=k, op=by_id[k].op) for k in sorted(consumers[first.id])],
                              proposed_members=[t.id for t in chain], accepted=len(chain) > 1 and chain[-1].op in activations))
            if len(chain) > 1 and chain[-1].op not in activations:
                rejected['incomplete_activation'] += 1
                chain = [first]
        used.update(t.id for t in chain)
        if len(chain) == 1:
            out.append(first.describe()); continue
        grouped, = group(chain, max_ops=max_ops)
        work = []
        for t in chain:
            dims = [(i.region[1]-i.region[0], i.region[3]-i.region[2]) if i.region else shapes[i.value] for i in t.inputs]
            work.append([t.op, task_work(t.op, t.attrs, t.shape, dims)])
        # Explicit synthetic operation: not a deployable runtime group. Model
        # final-result-only posting and preserve every original kernel cost.
        grouped.op = MODEL_OP
        grouped.attrs['extra_work'] = work
        out.append(grouped.describe())
        certificates.append(dict(output=grouped.id, members=[t.id for t in chain],
                                 memory_allowance_bytes=memory(chain),
                                 internal_float64_bytes=sum(nbytes(t.id) for t in chain[:-1])))
    g['tasks'] = out
    result['graph_sha256'] = digest(g)
    result['provenance'] = dict(kind='offline bounded grouping hypothesis', source_graph_sha256=data['graph_sha256'])
    available = {t['id'] for t in out} | g['leaves'].keys()
    if not protected <= available:
        raise ValueError('lost protected value')
    return result, dict(groups=certificates, rejected=rejected, roots=sorted(roots),
                        budget_bytes=budget_bytes, max_ops=max_ops, mode=mode, blas_scratch_bytes=blas_scratch_bytes, matmul_paths=paths)



def verify_grouping(original, candidate, certificate):
    """Expand groups symbolically and require the exact original tasks/operands."""
    before = {t['id']: t for t in original['graph']['tasks']}
    expanded = {}
    for task in candidate['graph']['tasks']:
        if task['op'] != MODEL_OP:
            expanded[task['id']] = task
            continue
        for node in task['attrs']['nodes']:
            inputs = [copy.deepcopy(task['inputs'][i['external']]) if 'external' in i
                      else dict(value=i['value'], region=i['region']) for i in node['inputs']]
            reconstructed = dict(id=node['id'], op=node['op'], inputs=inputs, shape=node['shape'], attrs=node['attrs'])
            if node['id'] in expanded:
                raise ValueError('duplicated grouped operation')
            expanded[node['id']] = reconstructed
    if digest(expanded) != digest(before):
        raise ValueError('group changed original operations or operand multiplicity')
    available = {t['id'] for t in candidate['graph']['tasks']} | candidate['graph']['leaves'].keys()
    if not set(certificate['roots']) <= available:
        raise ValueError('lost required root')
    if any(g['memory_allowance_bytes'] > certificate['budget_bytes'] for g in certificate['groups']):
        raise ValueError('group exceeds memory allowance')
    if candidate['graph_sha256'] != digest(candidate['graph']):
        raise ValueError('bad candidate checksum')
    return True


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--corpus', action='append', required=True)
    parser.add_argument('--output', required=True)
    parser.add_argument('--mode', choices=('cheap', 'matmul_activation', 'tile_epilogue'), default='cheap')
    args = parser.parse_args()
    out = Path(args.output).resolve(); out.mkdir(parents=True, exist_ok=False)
    rows, audits = [], []
    with patch('socket.socket.connect', side_effect=RuntimeError('offline only')), patch('ygaraty.runtime.kernels.execute', side_effect=RuntimeError('no workload execution')):
        for directory in args.corpus:
            root = Path(directory).resolve()
            manifest = json.loads((root / 'manifest.json').read_text())
            cost = CostModel.load(root / 'cost.json')
            if digest(cost.table) != manifest['cost_sha256']:
                raise ValueError('cost hash mismatch')
            table = copy.deepcopy(cost.table); table[MODEL_OP] = dict(a=0., b=0., samples=0)
            if args.mode == 'tile_epilogue':
                from .tile_epilogue import OP, PACK, WRAPPER
                table[OP] = dict(a=0., b=0., samples=0)
                table[PACK] = {**table['*'], 'samples': 0}
                table[WRAPPER] = dict(a=0., b=.001, samples=0)
            cost = CostModel(table)
            for w in manifest['workloads']:
                source = root / w['plan']; original_bytes = source.read_bytes()
                _, data = load_plan(source)
                roots, provenance = output_contract(data)
                if roots is None:
                    audits.append(dict(workload=w['name'], status='blocked', reason=provenance)); continue
                pruned, pruning = simplify(data, ['dead'], roots)
                variants = [('prune', pruned, {})]
                if args.mode == 'tile_epilogue':
                    from .tile_epilogue import transform
                    for mib in (1, 8):
                        for overhead in (0., .5, 2.):
                            candidate, cert = transform(pruned, roots, mib << 20, overhead)
                            variants.append((f'tile-{mib}MiB-{overhead:g}ms', candidate, cert))
                else:
                    for limit in ((2, 4) if args.mode == 'cheap' else (2, 3)):
                        for mib in ((1, 8) if args.mode == 'cheap' else (1, 8, 32)):
                            candidate, cert = bounded_group(pruned, roots, limit, mib << 20, mode=args.mode)
                            verify_grouping(pruned, candidate, cert)
                            variants.append((f'group{limit}-{mib}MiB', candidate, cert))
                for label, candidate, cert in variants:
                    with tempfile.TemporaryDirectory() as temp:
                        path = Path(temp) / 'plan.json'; path.write_text(json.dumps(candidate))
                        plan, _ = load_plan(path)
                    audit = dict(workload=w['name'], variant=label, status='modeled', tasks=len(plan.tasks),
                                 source_graph_sha256=data['graph_sha256'], graph_sha256=candidate['graph_sha256'],
                                 source_cost_sha256=manifest['cost_sha256'], root_provenance=provenance,
                                 pruning=pruning, grouping=cert, cost_coverage=cost.coverage(plan))
                    audits.append(audit)
                    with gzip.open(out / f"{w['name']}-{label}.json.gz", 'wt') as f:
                        json.dump(dict(plan=candidate, certificate=audit), f)
                    for scenario in manifest['scenarios']:
                        if scenario['name'] not in ('lan_4', 'home_4', 'heterogeneous_8'):
                            continue
                        for seed in (0, 1700, 1701, 1702):
                            settings = settings_for(scenario['settings']) if seed == 0 else scenario['settings']
                            if args.mode == 'tile_epilogue' and (settings.get('float32_wire') or settings.get('activation_bytes') not in (None, 8)):
                                raise ValueError('tile epilogue requires unchanged float64 transport boundaries')
                            for policy in ('fifo', 'critical_path'):
                                r = collect(plan, cost, policy, seed, settings)
                                rows.append(dict(workload=w['name'], variant=label, scenario=scenario['name'], policy=policy,
                                                 seed=seed, settings=settings, makespan_s=r['makespan_s']))
                if source.read_bytes() != original_bytes:
                    raise ValueError('source modified')
                print('Compared', w['name'], flush=True)
    results = []
    index = {(r['workload'], r['variant'], r['scenario'], r['policy'], r['seed']): r['makespan_s'] for r in rows}
    for workload in sorted({r['workload'] for r in rows}):
        for variant in sorted({r['variant'] for r in rows} - {'prune'}):
            for regime in ('deterministic', 'noisy'):
                gains = [100 * (1 - r['makespan_s'] / index[workload, 'prune', r['scenario'], r['policy'], r['seed']])
                         for r in rows if r['workload'] == workload and r['variant'] == variant and (r['seed'] == 0) == (regime == 'deterministic')]
                results.append(dict(workload=workload, variant=variant, regime=regime, mean_gain_percent=statistics.mean(gains), min_gain_percent=min(gains), max_gain_percent=max(gains)))
    with gzip.open(out / 'rollouts.jsonl.gz', 'wt') as f:
        for row in rows: f.write(json.dumps(row) + '\n')
    (out / 'report.json').write_text(json.dumps(dict(status='complete', mode=args.mode, scope='modeled only; additive kernel costs; tile_epilogue retains packed preactivation and activation; other groups publish final output only; not runtime validation', audits=audits, results=results, rollouts=len(rows)), indent=2))
    (out / 'plan_grouping.py').write_bytes(Path(__file__).read_bytes())
    with zipfile.ZipFile(out.with_suffix('.zip'), 'x', compression=zipfile.ZIP_DEFLATED) as z:
        for f in out.iterdir(): z.write(f, f.relative_to(out.parent))
    print(json.dumps(results, indent=2))


if __name__ == '__main__':
    main()
