"""Structural matmul epilogue checks; never execute numerical kernels."""
import unittest
from ygaraty.simulation.plan_grouping import bounded_group, verify_grouping
from ygaraty.simulation.reference import digest


class MatmulGroupingTests(unittest.TestCase):
    def fixture(self, bias=False):
        def task(k, op, inputs):
            return dict(id=k, op=op, inputs=[dict(value=v, region=None) for v in inputs], shape=[4, 4], attrs={})
        tasks = [task('m', 'matmul', ['x', 'w'])]
        if bias: tasks.append(task('b', 'add_bias', ['m', 'bias']))
        tasks.append(task('a', 'relu', ['b' if bias else 'm']))
        g = dict(tasks=tasks, leaves={k:dict(shape=[4,4]) for k in ('x','w','bias')}, reusable=[], owned=False, owner_keys=[])
        return dict(schema_version=1, graph=g, graph_sha256=digest(g))

    def run_group(self, data, roots=('a',), **kwargs):
        return bounded_group(data, roots, mode='matmul_activation', **kwargs)

    def test_direct_and_bias_exact_expansion_and_cost(self):
        for bias in (False, True):
            d = self.fixture(bias)
            r, c = self.run_group(d, max_ops=3)
            self.assertEqual(len(r['graph']['tasks']), 1)
            self.assertTrue(verify_grouping(d, r, c))
            work = r['graph']['tasks'][0]['attrs']['extra_work']
            self.assertEqual(work[0], ['matmul', 64])
            self.assertEqual(work[-1], ['relu', 32])
            self.assertGreater(c['groups'][0]['memory_allowance_bytes'], 1 << 20)

    def test_memory_roots_and_no_partial_bias_group(self):
        d = self.fixture(True)
        for kwargs in ({'budget_bytes': 1 << 20}, {'max_ops': 2}):
            r, c = self.run_group(d, **kwargs)
            self.assertFalse(c['groups'])
        r, c = self.run_group(d, roots=('a','m'))
        self.assertFalse(c['groups'])
        r, c = self.run_group(d, roots=('a','b'))
        self.assertFalse(c['groups'])

    def test_fanout_reduction_wire_and_nonactivation_rejected(self):
        for kind in ('fanout','reduction','wire','no_activation'):
            d = self.fixture()
            if kind == 'fanout':
                d['graph']['tasks'].append(dict(id='back', op='relu_backward', inputs=[dict(value='m',region=None)], shape=[4,4], attrs={}))
            elif kind == 'reduction': d['graph']['tasks'][1]['op'] = 'add_many'
            elif kind == 'wire': d['graph']['tasks'][0]['attrs']['wire'] = 'bf16'
            else: d['graph']['tasks'][1]['op'] = 'matmul'
            _, c = self.run_group(d)
            self.assertFalse(c['groups'])
