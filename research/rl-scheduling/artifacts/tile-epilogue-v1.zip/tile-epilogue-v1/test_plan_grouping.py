"""Structural only: no numerical workload kernels."""
import copy
import unittest
from ygaraty.simulation.plan_grouping import bounded_group, verify_grouping, MODEL_OP
from ygaraty.simulation.reference import digest


class GroupingTests(unittest.TestCase):
    def fixture(self):
        tasks = [dict(id=k, op='scale', inputs=[dict(value=v, region=None)], shape=[8, 8], attrs={'factor': 2.}) for k, v in [('a', 'x'), ('b', 'a'), ('c', 'b')]]
        g = dict(tasks=tasks, leaves={'x': {'shape': [8, 8]}}, reusable=[], owner_keys=[], owned=False)
        return dict(schema_version=1, graph=g, graph_sha256=digest(g))

    def test_output_preservation_cost_and_immutable_source(self):
        data = self.fixture(); original = copy.deepcopy(data)
        grouped, cert = bounded_group(data, ['c'])
        task, = grouped['graph']['tasks']
        self.assertEqual((task['id'], task['op']), ('c', MODEL_OP))
        self.assertEqual([n['id'] for n in task['attrs']['nodes']], ['a', 'b', 'c'])
        self.assertEqual(task['attrs']['extra_work'], [['scale', 128]] * 3)
        self.assertEqual(cert['groups'][0]['memory_allowance_bytes'], 6144)
        self.assertEqual(data, original)
        self.assertTrue(verify_grouping(data, grouped, cert))

    def test_roots_reusable_memory_and_wire_boundaries(self):
        for protect in ('roots', 'reusable'):
            data = self.fixture()
            roots = ['a', 'c'] if protect == 'roots' else ['c']
            if protect == 'reusable': data['graph']['reusable'] = ['a']
            grouped, _ = bounded_group(data, roots)
            self.assertIn('a', [t['id'] for t in grouped['graph']['tasks']])
        grouped, cert = bounded_group(self.fixture(), ['c'], budget_bytes=1)
        self.assertEqual(len(grouped['graph']['tasks']), 3)
        self.assertGreater(cert['rejected']['memory'], 0)
        data = self.fixture(); data['graph']['tasks'][1]['attrs']['wire'] = 'bf16'
        grouped, _ = bounded_group(data, ['c'])
        self.assertEqual(len(grouped['graph']['tasks']), 3)

    def test_fanout_join_and_unknown_contract(self):
        data = self.fixture()
        data['graph']['tasks'].append(dict(id='d', op='add', inputs=[dict(value='a', region=None), dict(value='c', region=None)], shape=[8, 8], attrs={}))
        grouped, cert = bounded_group(data, ['d'])
        self.assertIn('a', [t['id'] for t in grouped['graph']['tasks']])
        self.assertFalse(any('d' in c['members'] for c in cert['groups']))
        for roots in (None, ['missing']):
            with self.assertRaises(ValueError): bounded_group(data, roots)
        data['graph']['owned'] = True
        with self.assertRaises(ValueError): bounded_group(data, ['d'])

    def test_symbolic_expansion_preserves_repeated_sliced_operands(self):
        data = self.fixture()
        first = data['graph']['tasks'][0]
        first['op'] = 'mul'; first['attrs'] = {}
        first['inputs'] = [dict(value='x', region=[0, 8, 0, 8])] * 2
        grouped, cert = bounded_group(data, ['c'])
        self.assertTrue(verify_grouping(data, grouped, cert))
        grouped['graph']['tasks'][0]['attrs']['nodes'][0]['inputs'].pop()
        with self.assertRaises(ValueError): verify_grouping(data, grouped, cert)
