"""Offline communication/claim ablation on fixed pruned local graphs."""
import argparse
import gzip
import json
from pathlib import Path
import statistics
import tempfile
from unittest.mock import patch
import zipfile

from .cost import CostModel
from .plan_simplify import output_contract, simplify
from .reference import load_plan, digest
from .rl_counterfactual import settings_for
from .rl_dataset import collect

VARIANTS = {
    'baseline': {},
    'push': {'push_inputs': True},
    'batch4': {'max_tasks': 4},
    'batch4-stream': {'max_tasks': 4, 'stream_posts': True},
    'batch4-eager': {'max_tasks': 4, 'eager_claims': True},
    'push-batch2-eager': {'max_tasks': 2, 'push_inputs': True, 'eager_claims': True},
    'push-batch4-eager': {'max_tasks': 4, 'push_inputs': True, 'eager_claims': True},
    'push-batch8-eager': {'max_tasks': 8, 'push_inputs': True, 'eager_claims': True},
}


def metrics(result, workers):
    elapsed = result['makespan_s']
    compute = result['diagnostics']['worker_compute_s']
    capacity = workers * elapsed
    return dict(compute_worker_s=sum(compute.values()),
                noncompute_worker_s=capacity-sum(compute.values()),
                compute_utilization=sum(compute.values())/capacity,
                worker_compute_s=compute)


def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--corpus',action='append',required=True);p.add_argument('--output',required=True)
    a=p.parse_args();out=Path(a.output).resolve();out.mkdir(parents=True,exist_ok=False)
    rows=[];blocked=[]
    with patch('socket.socket.connect',side_effect=RuntimeError('offline only')),patch('ygaraty.runtime.kernels.execute',side_effect=RuntimeError('no numerical workloads')):
        for folder in a.corpus:
            root=Path(folder).resolve();manifest=json.loads((root/'manifest.json').read_text());cost=CostModel.load(root/'cost.json')
            if digest(cost.table)!=manifest['cost_sha256']:raise ValueError('cost mismatch')
            for workload in manifest['workloads']:
                source=root/workload['plan'];raw=source.read_bytes();_,original=load_plan(source)
                roots,reason=output_contract(original)
                if roots is None:blocked.append(dict(workload=workload['name'],reason=reason));continue
                pruned,cert=simplify(original,['dead'],roots)
                with tempfile.TemporaryDirectory() as temp:
                    path=Path(temp)/'plan.json';path.write_text(json.dumps(pruned));plan,_=load_plan(path)
                with gzip.open(out/(workload['name']+'-plan.json.gz'),'wt') as f:json.dump(dict(plan=pruned,certificate=cert),f)
                for scenario in manifest['scenarios']:
                    if scenario['name'] not in ('lan_4','home_4','heterogeneous_8'):continue
                    for seed in (0,1800,1801):
                        base=settings_for(scenario['settings']) if seed==0 else scenario['settings']
                        for name,changes in VARIANTS.items():
                            settings={**base,**changes}
                            r=collect(plan,cost,'critical_path',seed,settings,diagnostics=True)
                            rows.append(dict(workload=workload['name'],scenario=scenario['name'],variant=name,seed=seed,
                                settings=settings,graph_sha256=pruned['graph_sha256'],cost_sha256=manifest['cost_sha256'],
                                makespan_s=r['makespan_s'],metrics=metrics(r,settings['workers']),diagnostics=r['diagnostics']))
                if source.read_bytes()!=raw:raise ValueError('source changed')
                print('Compared',workload['name'],flush=True)
            (out/(root.name+'-cost.json')).write_text(json.dumps(cost.table,indent=2))
    index={(r['workload'],r['scenario'],r['variant'],r['seed']):r for r in rows}
    summary=[]
    for workload in sorted({r['workload'] for r in rows}):
        for scenario in ('lan_4','home_4','heterogeneous_8'):
            for variant in VARIANTS:
                for regime in ('deterministic','noisy'):
                    subset=[r for r in rows if r['workload']==workload and r['scenario']==scenario and r['variant']==variant and (r['seed']==0)==(regime=='deterministic')]
                    gains=[100*(1-r['makespan_s']/index[workload,scenario,'baseline',r['seed']]['makespan_s']) for r in subset]
                    summary.append(dict(workload=workload,scenario=scenario,variant=variant,regime=regime,
                        mean_gain_percent=statistics.mean(gains),mean_noncompute_worker_s=statistics.mean(r['metrics']['noncompute_worker_s'] for r in subset),
                        mean_compute_utilization=statistics.mean(r['metrics']['compute_utilization'] for r in subset)))
    with gzip.open(out/'rollouts.jsonl.gz','wt') as f:
        for r in rows:f.write(json.dumps(r)+'\n')
    (out/'report.json').write_text(json.dumps(dict(status='complete',rollouts=len(rows),blocked=blocked,results=summary,
        scope='modeled only, unchanged pruned graphs, critical-path policy; noncompute includes network/startup and is not pure dependency idle'),indent=2))
    (out/'worker_wait.py').write_bytes(Path(__file__).read_bytes())
    with zipfile.ZipFile(out.with_suffix('.zip'),'x',compression=zipfile.ZIP_DEFLATED) as z:
        for f in out.iterdir():z.write(f,f.relative_to(out.parent))


if __name__=='__main__':main()
