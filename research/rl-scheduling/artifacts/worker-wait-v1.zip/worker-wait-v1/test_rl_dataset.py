"""Offline checks for trajectory legality and reward semantics."""
from types import SimpleNamespace
import unittest
from unittest.mock import patch
from ygaraty.compiler.plan import Input, Task
from ygaraty.simulation.cost import CostModel
from ygaraty.simulation.rl_dataset import collect


def fixture():
    return SimpleNamespace(tasks=[Task('a','scale',[Input('x')],(2,2)),
        Task('b','scale',[Input('x')],(2,2)), Task('c','add',[Input('a'),Input('b')],(2,2))],
        leaves={'x':{'shape':[2,2]}}, reusable={'x'}, owner_keys=[], owned=False)


class DatasetTests(unittest.TestCase):
    def test_legal_complete_reproducible_offline_trajectories(self):
        cost = CostModel({'*':dict(a=.01,b=0)})
        with patch('socket.socket', side_effect=AssertionError('network forbidden')):
            for policy in ('fifo','shortest','random'):
                a = collect(fixture(),cost,policy,3,dict(workers=2,max_tasks=1))
                self.assertEqual(a,collect(fixture(),cost,policy,3,dict(workers=2,max_tasks=1)))
                rows = a['transitions']
                self.assertEqual(len(rows),3)
                self.assertEqual(sum(r['done'] for r in rows),1)
                self.assertAlmostEqual(sum(r['reward'] for r in rows),-a['makespan_s'])
                for i, row in enumerate(rows):
                    self.assertIn(row['action'],row['legal_actions'])
                    self.assertGreaterEqual(row['elapsed_s'],0)
                    if row['action']=='c':
                        self.assertTrue({'a','b'} <= set(row['observation']['committed']))
                    if i+1<len(rows):
                        self.assertEqual(row['next_observation'],rows[i+1]['observation'])
                self.assertEqual(set(rows[-1]['next_observation']['committed']),{'a','b','c'})

    def test_owned_plans_rejected(self):
        plan=fixture(); plan.owned=True
        with self.assertRaisesRegex(ValueError,'unowned'):
            collect(plan,CostModel({'*':dict(a=.01,b=0)}),'fifo',0,{})

    def test_optional_diagnostics_preserve_trajectory_and_account_compute(self):
        cost=CostModel({'*':dict(a=.01,b=0)})
        settings=dict(workers=2,max_tasks=1,updates=1,noise=0,jitter_ms=0)
        with patch('socket.socket',side_effect=AssertionError('network forbidden')):
            plain=collect(fixture(),cost,'critical_path',0,settings)
            detailed=collect(fixture(),cost,'critical_path',0,settings,diagnostics=True)
        diagnostics=detailed.pop('diagnostics')
        self.assertEqual(plain,detailed)
        self.assertAlmostEqual(sum(diagnostics['worker_compute_s'].values()),.03)
        from ygaraty.simulation.worker_wait import metrics
        m=metrics({**detailed,'diagnostics':diagnostics},2)
        self.assertAlmostEqual(m['noncompute_worker_s']+.03,2*detailed['makespan_s'])
        self.assertTrue(0 <= m['compute_utilization'] <= 1)
