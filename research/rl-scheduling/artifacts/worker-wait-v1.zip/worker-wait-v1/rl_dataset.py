"""Collect simulated scheduling trajectories from local graph snapshots; never train."""
import argparse
import hashlib
import inspect
import json
import random
from pathlib import Path

from ygaraty.compiler.cost import task_work
from ygaraty.runtime.scheduler import Scheduler
from .cost import CostModel, METADATA_OPS
from .engine import Simulation
from .reference import digest, load_plan

POLICIES = ('fifo', 'shortest', 'random', 'critical_path', 'cache')


def collect(plan, cost, policy, seed, settings, *, diagnostics=False):
    """One episode = one update. Observations are partial, not simulator checkpoints."""
    if policy not in POLICIES:
        raise ValueError('unknown behavior policy')
    if plan.owned or getattr(plan, 'replicated', False) or any(t.attrs.get('owner') for t in plan.tasks):
        raise ValueError('v1 supports unowned task ordering only')
    if settings.get('updates', 1) != 1:
        raise ValueError('one update per episode required')
    sim = Simulation(plan, cost, **{**settings, 'seed': seed, 'updates': 1})
    rng = random.Random(seed)  # Do not consume the simulator noise RNG.
    rows = []
    estimates = {}
    for task in plan.tasks:
        dims = [(i.region[1]-i.region[0], i.region[3]-i.region[2]) if i.region else sim.shapes[i.value]
                for i in task.inputs]
        estimates[task.id] = (0.0 if task.op in METADATA_OPS else cost.seconds(task.op, task_work(task.op, task.attrs, task.shape, dims))
                             + sum(cost.seconds(op, work) for op, work in task.attrs.get('extra_work', ())))

    # Reverse topological dynamic programming, independent of serialized task order.
    from collections import deque
    waiting = dict(sim.scheduler.waiting)
    queue = deque(sim.scheduler.ready)
    order = []
    while queue:
        ident = queue.popleft()
        order.append(ident)
        for child in sim.scheduler.dependents.get(ident, []):
            waiting[child] -= 1
            if waiting[child] == 0:
                queue.append(child)
    ranks = {}
    for ident in reversed(order):
        ranks[ident] = estimates[ident] + max(
            (ranks[child] for child in sim.scheduler.dependents.get(ident, [])), default=0.)

    def observe(worker=None):
        return dict(time_s=sim.now, worker=worker, ready=list(sim.scheduler.ready),
                    committed=sorted(sim.scheduler.committed),
                    running={k: v.worker.decode() for k, v in sorted(sim.scheduler.running.items())},
                    worker_queue_lengths={w: len(q) for w, q in sim.queues.items()},
                    cached_bytes={w: sum(c.entries.values()) for w, c in sim.caches.items()})

    def choose(ready, worker):
        legal = list(ready)
        if policy == 'random':
            index = rng.randrange(len(legal))
        elif policy == 'shortest':
            index = min(range(len(legal)), key=lambda i: estimates[legal[i]])
        elif policy == 'critical_path':
            index = max(range(len(legal)), key=lambda i: ranks[legal[i]])
        elif policy == 'cache':
            entries = sim.caches[worker.decode()].entries
            def held(ident):
                keys = {sim.input_cache_key(inp) for inp in sim.scheduler.tasks[ident].inputs}
                return sum(entries.get(key, 0) for key in keys)
            index = max(range(len(legal)), key=lambda i: held(legal[i]))
        else:
            index = 0
        rows.append(dict(observation=observe(worker.decode()), legal_actions=legal,
                         action=legal[index], behavior_probability=1/len(legal) if policy == 'random' else 1.0))
        return index

    sim.choose = choose
    sim.run()
    terminal = observe()
    for i, row in enumerate(rows):
        done = i == len(rows)-1
        next_obs = terminal if done else rows[i+1]['observation']
        row.update(step=i, next_observation=next_obs, done=done,
                   elapsed_s=next_obs['time_s']-row['observation']['time_s'],
                   reward=-sim.now if done else 0.0)
    result = dict(policy=policy, seed=seed, makespan_s=sim.now, estimates_s=estimates,
                  transitions=rows, cost_coverage=sim.coverage)
    if diagnostics:
        result['diagnostics'] = sim.report()
        result['diagnostics']['worker_compute_s'] = {
            w: float(sim.stats[-1][w].get('compute', 0.)) for w in sim.names}
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--plan', required=True)
    parser.add_argument('--cost-model', required=True)
    parser.add_argument('--output', required=True, help='new output directory; refuses overwrite')
    parser.add_argument('--seeds', type=int, default=4)
    parser.add_argument('--workers', type=int, default=2)
    args = parser.parse_args()
    if args.seeds < 1:
        parser.error('--seeds must be positive')
    plan, snapshot = load_plan(Path(args.plan).resolve())
    cost = CostModel.load(Path(args.cost_model).resolve())
    settings = dict(workers=args.workers, max_tasks=1, updates=1, noise=.1, jitter_ms=5)
    # Complete validation/collection before creating any output.
    episodes = [collect(plan, cost, policy, seed, settings)
                for policy in POLICIES for seed in range(args.seeds)]
    out = Path(args.output).resolve()
    out.mkdir(parents=True, exist_ok=False)
    (out/'plan.json').write_text(json.dumps(snapshot, indent=2)+'\n')
    (out/'cost.json').write_text(json.dumps(cost.table, indent=2)+'\n')
    count = 0
    summaries = []
    with (out/'transitions.jsonl').open('w') as stream:
        for episode_id, episode in enumerate(episodes):
            for row in episode.pop('transitions'):
                stream.write(json.dumps(dict(schema_version=1, source='modeled', episode_id=episode_id,
                    policy=episode['policy'], seed=episode['seed'], **row), allow_nan=False)+'\n')
                count += 1
            summaries.append(dict(episode_id=episode_id, **episode))
    manifest = dict(schema_version=1, source='modeled', purpose='pipeline pilot, not a training-quality corpus',
        graph_sha256=snapshot['graph_sha256'], cost_sha256=digest(cost.table), settings=settings,
        observation='partial; no future outcomes or sampled kernel durations',
        reward='zero except terminal negative episode makespan in seconds; use undiscounted return',
        split_group='graph_sha256; all policies and seeds of this graph stay in the same split',
        limitations=['unowned task ordering only; worker arrival is environment-controlled',
                     'no ownership, placement, wait action, failures or churn',
                     'cache identities and hidden transfer queues omitted; history may be required',
                     'simulated rewards are not measured performance'],
        source_sha256={name: hashlib.sha256(inspect.getsource(obj).encode()).hexdigest()
                       for name, obj in [('collector', inspect.getmodule(collect)), ('engine', inspect.getmodule(Simulation)),
                                         ('scheduler', inspect.getmodule(Scheduler)), ('cost', inspect.getmodule(CostModel))]},
        episodes=summaries, transition_count=count)
    manifest['transitions_sha256'] = hashlib.sha256((out/'transitions.jsonl').read_bytes()).hexdigest()
    (out/'manifest.json').write_text(json.dumps(manifest, indent=2, allow_nan=False)+'\n')
    print(f'{len(episodes)} modeled episodes, {count} transitions: {out}')


if __name__ == '__main__':
    main()
